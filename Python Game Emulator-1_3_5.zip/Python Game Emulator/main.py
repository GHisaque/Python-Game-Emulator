import pygame
import json
import os

pygame.init()

# --- Settings ---
WIDTH, HEIGHT = 1020, 780
TOOLBOX_WIDTH = 200
FPS = 60
FONT = pygame.font.SysFont("arial", 16)

# --- Colors ---
WHITE = (255, 255, 255)
GRAY = (180, 180, 180)
DARK_GRAY = (50, 50, 50)
BLACK = (0, 0, 0)
COLOR_MAP = {
    "red": (255, 0, 0),
    "yellow": (255, 255, 0),
    "blue": (0, 0, 255),
    "green": (0, 255, 0),
    "gray": GRAY
}

# --- Load project file (scene + toolbox) ---
def load_project_with_toolbox(filename):
    with open(filename, "r") as f:
        data = json.load(f)
    scene_objects = data.get("scene", {}).get("objects", [])
    toolbox = list(data.get("toolbox", {}).items())
    return scene_objects, toolbox

def save_project_with_toolbox(filename, scene_objects, toolbox):
    toolbox_dict = {obj["_name_"]: obj for _, obj in toolbox}
    data = {
        "scene": {"objects": scene_objects},
        "toolbox": toolbox_dict
    }
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

# --- Helpers ---
def get_color_from_obj(obj):
    for p in obj.get("_properties_", {}).values():
        if p.get("_name_") == "color":
            return COLOR_MAP.get(p.get("_value_"), GRAY)
    return GRAY

def get_pos_from_obj(obj):
    x = y = 0
    for prop in obj["_properties_"].values():
        if prop["_name_"] == "x":
            x = int(prop["_value_"])
        elif prop["_name_"] == "y":
            y = int(prop["_value_"])
    return x, y

def set_pos(obj, x, y):
    for prop in obj["_properties_"].values():
        if prop["_name_"] == "x":
            prop["_value_"] = x
        elif prop["_name_"] == "y":
            prop["_value_"] = y

def clone_object(obj):
    return json.loads(json.dumps(obj))

def get_script_from_obj(obj):
    return obj.get("_script_", "")

def define_script_from_obj(obj, newScript):
    obj["_script_"] = str(newScript)

def is_colliding(obj1, obj2, size=40):
    x1, y1 = get_pos_from_obj(obj1)
    x2, y2 = get_pos_from_obj(obj2)
    return (x1 < x2 + size and x1 + size > x2 and y1 < y2 + size and y1 + size > y2)

def run_object_script(obj, keys):
    script = get_script_from_obj(obj)
    if not script:
        return
    x, y = get_pos_from_obj(obj)
    if "_vars_" not in obj:
        obj["_vars_"] = {}
    context = {
        "x": x,
        "y": y,
        "keys": keys,
        "pygame": pygame,
        **obj["_vars_"]
    }
    try:
        exec(script, {}, context)
    except Exception as e:
        print(f"Script error in {obj.get('_name_', 'Unknown')}: {e}")
    set_pos(obj, int(context.get("x", x)), int(context.get("y", y)))
    for key in list(context):
        if key not in ("x", "y", "keys", "pygame"):
            obj["_vars_"][key] = context[key]

# --- Init ---
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My Game Editor")
clock = pygame.time.Clock()

PROJECT_NAME = "demo_game"
PROJECT_FILE = PROJECT_NAME + ".gscene"
scene_objects, toolbox_objects = load_project_with_toolbox(PROJECT_FILE)
placed_objects = scene_objects

keys_down = set()
dragging = None
drag_offset = (0, 0)
play_mode = False
selected_object = None
editing_script = False
script_scroll_offset = 0
edited_text = ""

# --- Main loop ---
running = True
while running:
    screen.fill(DARK_GRAY)
    pygame.draw.rect(screen, GRAY, (0, 0, TOOLBOX_WIDTH, HEIGHT))

    # --- Events ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            keys_down.add(event.key)

            if event.key == pygame.K_p:
                play_mode = not play_mode
                print("Play mode" if play_mode else "Edit mode")

            if selected_object and event.key == pygame.K_e:
                if not editing_script:
                    edited_text = get_script_from_obj(selected_object)
                    script_scroll_offset = 0
                else:
                    edited_text = ""
                editing_script = not editing_script

            elif editing_script:
                if event.key == pygame.K_RETURN:
                    define_script_from_obj(selected_object, edited_text)
                    editing_script = False
                elif event.key == pygame.K_BACKSPACE:
                    edited_text = edited_text[:-1]
                elif event.key == pygame.K_TAB:
                    edited_text += "    "
                else:
                    if event.unicode.isprintable():
                        edited_text += event.unicode

            # Script scrolling (viewing or editing)
            if selected_object:
                lines = (edited_text if editing_script else get_script_from_obj(selected_object)).splitlines()
                max_scroll = max(0, len(lines) - 10)  # 10 visible lines

                if event.key in (pygame.K_PAGEUP, pygame.K_UP):
                    script_scroll_offset = max(0, script_scroll_offset - 1)
                elif event.key in (pygame.K_PAGEDOWN, pygame.K_DOWN):
                    script_scroll_offset = min(max_scroll, script_scroll_offset + 1)

        if event.type == pygame.KEYUP:
            keys_down.discard(event.key)

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()
            if mx < TOOLBOX_WIDTH and not play_mode:
                index = my // 40
                if 0 <= index < len(toolbox_objects):
                    _, obj_data = toolbox_objects[index]
                    new_obj = clone_object(obj_data)
                    set_pos(new_obj, TOOLBOX_WIDTH + 20, my)
                    placed_objects.append(new_obj)
            elif not play_mode:
                for obj in reversed(placed_objects):
                    x, y = get_pos_from_obj(obj)
                    if x <= mx <= x + 40 and y <= my <= y + 40:
                        dragging = obj
                        drag_offset = (mx - x, my - y)
                        selected_object = obj
                        script_scroll_offset = 0
                        break

        if event.type == pygame.MOUSEBUTTONUP and not play_mode:
            dragging = None

    # --- Drag logic ---
    if dragging and not play_mode:
        mx, my = pygame.mouse.get_pos()
        set_pos(dragging, mx - drag_offset[0], my - drag_offset[1])

    # --- Play Mode Logic ---
    if play_mode:
        for obj in placed_objects:
            if get_script_from_obj(obj):
                run_object_script(obj, keys_down)
            else:
                x, y = get_pos_from_obj(obj)
                set_pos(obj, x + 2, y)

    # --- Collision ---
    player = None
    coins = []
    for obj in placed_objects:
        if obj["_name_"] == "Player":
            player = obj
        elif obj["_name_"] == "Coin":
            coins.append(obj)

    if play_mode and player:
        for coin in coins:
            if is_colliding(player, coin):
                placed_objects.remove(coin)

    # --- Draw toolbox ---
    for i, (name, obj) in enumerate(toolbox_objects):
        pygame.draw.rect(screen, DARK_GRAY, (0, i * 40, TOOLBOX_WIDTH, 40))
        label = FONT.render(obj["_name_"], True, WHITE)
        screen.blit(label, (10, i * 40 + 10))

    # --- Draw objects ---
    for obj in placed_objects:
        x, y = get_pos_from_obj(obj)
        color = get_color_from_obj(obj)
        pygame.draw.rect(screen, color, (x, y, 40, 40))
        label = FONT.render(obj["_name_"], True, BLACK)
        screen.blit(label, (x + 4, y + 12))

    # --- Show selected script ---
    if selected_object:
        script_text = edited_text if editing_script else get_script_from_obj(selected_object)
        lines = script_text.splitlines()
        header = "EDITING SCRIPT - Press Enter to save" if editing_script else "Script (press E to edit)"
        screen.blit(FONT.render(header, True, WHITE), (TOOLBOX_WIDTH + 10, HEIGHT - 180))

        # Max lines that fit in view
        max_visible_lines = 10
        visible_lines = lines[script_scroll_offset:script_scroll_offset + max_visible_lines]

        for i, line in enumerate(visible_lines):
            line_label = FONT.render(line, True, (255, 255, 100) if editing_script else WHITE)
            screen.blit(line_label, (TOOLBOX_WIDTH + 10, HEIGHT - 160 + i * 16))

    # --- UI Mode indicator ---
    mode_text = "PLAY MODE - P = stop" if play_mode else "EDIT MODE - P = play"
    mode_label = FONT.render(mode_text, True, WHITE)
    screen.blit(mode_label, (TOOLBOX_WIDTH + 10, 10))

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
