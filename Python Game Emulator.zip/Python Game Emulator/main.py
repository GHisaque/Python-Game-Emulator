import pygame
import json
import os

pygame.init()

# --- Settings ---
WIDTH, HEIGHT = 800, 600
TOOLBOX_WIDTH = 200
FPS = 60
FONT = pygame.font.SysFont("arial", 16)

# --- Colors ---
WHITE = (255, 255, 255)
GRAY = (180, 180, 180)
DARK_GRAY = (50, 50, 50)
BLACK = (0, 0, 0)
COLOR_MAP = {
    "red": (255, 0, 0),
    "yellow": (255, 255, 0),
    "blue": (0, 0, 255),
    "green": (0, 255, 0),
    "gray": GRAY
}

# --- Load project file (scene + toolbox) ---
def load_project_with_toolbox(filename):
    with open(filename, "r") as f:
        data = json.load(f)
    scene_objects = data.get("scene", {}).get("objects", [])
    toolbox = list(data.get("toolbox", {}).items())  # [(name, obj), ...]
    return scene_objects, toolbox

def save_project_with_toolbox(filename, scene_objects, toolbox):
    toolbox_dict = {obj["_name_"]: obj for _, obj in toolbox}
    data = {
        "scene": {"objects": scene_objects},
        "toolbox": toolbox_dict
    }
    with open(filename, "w") as f:
        json.dump(data, f, indent=4)

# --- Helpers ---
def get_color_from_obj(obj):
    props = obj.get("_properties_", {})
    for p in props.values():
        if p.get("_name_") == "color":
            return COLOR_MAP.get(p.get("_value_"), GRAY)
    return GRAY

def get_pos_from_obj(obj):
    x = y = 0
    for prop in obj["_properties_"].values():
        if prop["_name_"] == "x":
            x = int(prop["_value_"])
        if prop["_name_"] == "y":
            y = int(prop["_value_"])
    return x, y

def set_pos(obj, x, y):
    for prop in obj["_properties_"].values():
        if prop["_name_"] == "x":
            prop["_value_"] = x
        if prop["_name_"] == "y":
            prop["_value_"] = y

def clone_object(obj):
    return json.loads(json.dumps(obj))  # deep copy

def get_script_from_obj(obj):
    return obj.get("_script_", None)  # Optional custom scripting property

# --- Basic input key state (simplified) ---
keys_down = set()

# --- Pygame setup ---
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("My Game Editor with Play Mode")
clock = pygame.time.Clock()

# --- Load project ---
PROJECT_FILE = "demo_game.gscene"
scene_objects, toolbox_objects = load_project_with_toolbox(PROJECT_FILE)
placed_objects = scene_objects  # initially placed objects

dragging = None
drag_offset = (0, 0)
play_mode = False

def is_colliding(obj1, obj2, size=40):
    x1, y1 = get_pos_from_obj(obj1)
    x2, y2 = get_pos_from_obj(obj2)

    return (x1 < x2 + size and
            x1 + size > x2 and
            y1 < y2 + size and
            y1 + size > y2)

# --- Simple sandboxed exec context for scripts ---
def run_object_script(obj, keys):
    script = get_script_from_obj(obj)
    if not script:
        return

    x, y = get_pos_from_obj(obj)

    # Persistent per-object variable memory
    if "_vars_" not in obj:
        obj["_vars_"] = {}

    context = {
        "x": x,
        "y": y,
        "keys": keys,
        "pygame": pygame,  # so pygame.K_LEFT etc works
        **obj["_vars_"]     # inject object memory
    }

    try:
        exec(script, {}, context)
    except Exception as e:
        print(f"Script error in {obj.get('_name_', 'Unknown')}: {e}")

    # Update back values
    set_pos(obj, int(context.get("x", x)), int(context.get("y", y)))

    # Save updated variables (remove x/y/keys/pygame from memory)
    for key in list(context):
        if key not in ("x", "y", "keys", "pygame"):
            obj["_vars_"][key] = context[key]

# --- Main loop ---
running = True
while running:
    screen.fill(DARK_GRAY)
    pygame.draw.rect(screen, GRAY, (0, 0, TOOLBOX_WIDTH, HEIGHT))

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:
            keys_down.add(event.key)
            if event.key == pygame.K_p:
                play_mode = not play_mode
                print("Play mode" if play_mode else "Edit mode")

        if event.type == pygame.KEYUP:
            keys_down.discard(event.key)

        if event.type == pygame.MOUSEBUTTONDOWN:
            mx, my = pygame.mouse.get_pos()
            if mx < TOOLBOX_WIDTH and not play_mode:
                # Toolbox click to add object
                index = my // 40
                if 0 <= index < len(toolbox_objects):
                    _, obj_data = toolbox_objects[index]
                    new_obj = clone_object(obj_data)
                    set_pos(new_obj, TOOLBOX_WIDTH + 20, my)
                    placed_objects.append(new_obj)

            elif not play_mode:
                # Drag start on canvas in edit mode
                mx, my = pygame.mouse.get_pos()
                for obj in reversed(placed_objects):  # top to bottom
                    x, y = get_pos_from_obj(obj)
                    if x <= mx <= x + 40 and y <= my <= y + 40:
                        dragging = obj
                        drag_offset = (mx - x, my - y)
                        break

        if event.type == pygame.MOUSEBUTTONUP and not play_mode:
            dragging = None

    # Drag move (edit mode only)
    if dragging and not play_mode:
        mx, my = pygame.mouse.get_pos()
        new_x = mx - drag_offset[0]
        new_y = my - drag_offset[1]
        set_pos(dragging, new_x, new_y)

    # Play mode logic: update objects with basic script or default move right
    if play_mode:
        for obj in placed_objects:
            # If object has script, run it with keys
            if get_script_from_obj(obj):
                run_object_script(obj, keys_down)
            else:
                # Default simple behavior: move right 2 px per frame
                x, y = get_pos_from_obj(obj)
                set_pos(obj, x + 2, y)

    # Draw toolbox
    for i, (name, obj) in enumerate(toolbox_objects):
        pygame.draw.rect(screen, DARK_GRAY, (0, i * 40, TOOLBOX_WIDTH, 40))
        label = FONT.render(obj["_name_"], True, WHITE)
        screen.blit(label, (10, i * 40 + 10))

    # Identify player and coins
    player = None
    coins = []
    for obj in placed_objects:
        if obj["_name_"] == "Player":
            player = obj
        elif obj["_name_"] == "Coin":
            coins.append(obj)

    # Handle collision: remove coins touched by player
    if play_mode and player:
        for coin in coins:
            if is_colliding(player, coin):
                placed_objects.remove(coin)

    # Draw placed objects
    for obj in placed_objects:
        x, y = get_pos_from_obj(obj)
        color = get_color_from_obj(obj)
        pygame.draw.rect(screen, color, (x, y, 40, 40))
        name = obj["_name_"]
        label = FONT.render(name, True, BLACK)
        screen.blit(label, (x + 4, y + 12))


    # Draw mode indicator
    mode_text = "PLAY MODE - Press 'P' to stop" if play_mode else "EDIT MODE - Press 'P' to play"
    mode_label = FONT.render(mode_text, True, WHITE)
    screen.blit(mode_label, (TOOLBOX_WIDTH + 10, 10))

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
